// kabob

// railroad
	// build R with CSS
	// flip R for perspective
	// build train
		// engine
		// caboose
	// train moves around r
		// whole circle rotates
		// wheels spin perpendicular